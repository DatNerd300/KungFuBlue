package alexhart.csc309assign1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class RelativeSizeCalculator extends AppCompatActivity {
    TextView output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative_size_calculator);
        Button calculate = (Button) findViewById(R.id.calculateButton);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // grab length
                EditText lengthBox = (EditText) findViewById(R.id.lengthBox);
                // grab speed
                EditText speedBox = (EditText) findViewById(R.id.speedBox);
                double userSpeed;
                double userLength;
                // convert strings to floats
                if(lengthBox.toString() == null || speedBox.toString() == null){
                    return;
                }
                else {
                    userLength = Double.parseDouble(lengthBox.toString());
                    userSpeed = Double.parseDouble(speedBox.toString());
                }

                double out = userLength * Math.sqrt(1-(Math.pow(userSpeed, 2))/ Math.pow(299792458, 2));
                // now we calculate the relative length
                output.setText(String.format("%0.4f", out));
            }
        });

    }
}
